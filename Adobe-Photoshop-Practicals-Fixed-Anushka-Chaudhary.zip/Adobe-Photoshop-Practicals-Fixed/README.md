# Adobe Photoshop Practicals — UAC012P

Starter artwork pack for the six Desktop Publishing practicals.

## Student details to update
Replace `Anushka Chaudhary`, `253026043`, and `Your Semester` in each practical and its README before submission.

## Practical folders
- Practical-01: Basic tools and shapes
- Practical-02: Photo editing and retouching (layout mockup; must be replaced with genuine photo retouching)
- Practical-03: Layers, masks and creative composition (starter visual; add three separate photos and real masks)
- Practical-04: Selection and color correction (concept mockup; replace with genuine photo and adjustment layers)
- Practical-05: Filters, custom brushes and blending modes (starter visual; apply actual Photoshop effects)
- Practical-06: Promotional poster starter

## Important
The PNG/JPG/SVG artwork is a starting point, not proof that every required Photoshop technique has been performed. Open in Photoshop, add/organize real layers and apply the techniques described in each README, then save the final editable PSD and export the final JPG/PNG. Check the assignment PDF for exact requirements.


**Editable-layer PSD pack:** The PSDs have separate raster layers for each SVG artwork element and use RGB colour. Individual elements can be selected, moved, hidden, or recoloured with layer styles/adjustments. Text is separated but rasterized, not live editable type; replace text with Photoshop Type Tool for fully editable wording. Complete any required real photo retouching, masks, filters, and adjustment layers in Photoshop before submission.




**Student details added:** Anushka Chaudhary — Roll No. 253026043.
**Layered PSDs:** Each practical PSD contains a merged colour preview and separate raster layers for the artwork elements, including the background at the bottom. Text is separated per text object but rasterized; recreate text with Photoshop's Type Tool for live text editing.
