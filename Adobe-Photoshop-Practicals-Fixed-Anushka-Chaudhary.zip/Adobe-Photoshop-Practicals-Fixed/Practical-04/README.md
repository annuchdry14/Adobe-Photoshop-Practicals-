# Practical 04 – Advanced Selection and Color Correction

## Student Details
- Name: Anushka Chaudhary (replace before submission)
- Roll Number: 253026043 (replace before submission)
- Course: BCA
- Semester: Your Semester

## Objective
Select a subject, refine edges, use at least two adjustment layers and a layer mask, then show original and edited versions.

## Tools / techniques
Quick Selection / Magic Wand / Lasso, Levels or Curves, Hue/Saturation, Color Balance and Layer Mask. IMPORTANT: replace this concept mockup with a real photograph and adjustment layers before submission.

## Output
Artwork is included as PNG/JPG and SVG source. Open the artwork in Adobe Photoshop, review/edit it, replace student placeholders, and save the final PSD. Ensure the practical demonstrates the techniques listed in the assignment.

## Files
- PSD: `Practical_04_Name_RollNo.psd` (if included; check/edit before final submission)
- JPG: `Practical_04_Name_RollNo.jpg`
- PNG: `Practical_04_Name_RollNo.png`
- SVG source: `Practical_04_Artwork.svg`




**Updated PSD note:** The background is included as its own separate raster layer at the bottom of the layer stack, and the artwork elements are on separate layers. Text objects are separate raster layers, not live Type Tool text. For editable wording, recreate text with Photoshop's Type Tool; for native vector shapes, recreate with the Shape Tool.
