# Practical 06 – Complete Promotional Poster

## Student Details
- Name: Anushka Chaudhary (replace before submission)
- Roll Number: 253026043 (replace before submission)
- Course: BCA
- Semester: Your Semester

## Objective
Design a promotional poster with event name, date/time, venue, organizer, images and typography; use layers, mask, adjustment, advanced selection, filter, blending mode, layer style and brush effect.

## Tools / techniques
Integrated Photoshop techniques from Modules 1 and 2. Replace placeholder details and ensure the named techniques are genuinely used in the editable PSD.

## Output
Artwork is included as PNG/JPG and SVG source. Open the artwork in Adobe Photoshop, review/edit it, replace student placeholders, and save the final PSD. Ensure the practical demonstrates the techniques listed in the assignment.

## Files
- PSD: `Practical_06_Name_RollNo.psd` (if included; check/edit before final submission)
- JPG: `Practical_06_Name_RollNo.jpg`
- PNG: `Practical_06_Name_RollNo.png`
- SVG source: `Practical_06_Artwork.svg`




**Updated PSD note:** The background is included as its own separate raster layer at the bottom of the layer stack, and the artwork elements are on separate layers. Text objects are separate raster layers, not live Type Tool text. For editable wording, recreate text with Photoshop's Type Tool; for native vector shapes, recreate with the Shape Tool.
