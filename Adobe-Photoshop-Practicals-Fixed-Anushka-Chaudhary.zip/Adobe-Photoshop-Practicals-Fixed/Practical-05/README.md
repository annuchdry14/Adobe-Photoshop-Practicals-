# Practical 05 – Filters, Custom Brushes and Blending Modes

## Student Details
- Name: Anushka Chaudhary (replace before submission)
- Roll Number: 253026043 (replace before submission)
- Course: BCA
- Semester: Your Semester

## Objective
Create a 1200 × 800 artwork with a background, two filters, custom brush, two blending modes, layer style and text.

## Tools / techniques
Filters, custom brush, Multiply/Screen/Overlay, Drop Shadow or Outer Glow. IMPORTANT: apply these techniques as real Photoshop layers/filters before submission.

## Output
Artwork is included as PNG/JPG and SVG source. Open the artwork in Adobe Photoshop, review/edit it, replace student placeholders, and save the final PSD. Ensure the practical demonstrates the techniques listed in the assignment.

## Files
- PSD: `Practical_05_Name_RollNo.psd` (if included; check/edit before final submission)
- JPG: `Practical_05_Name_RollNo.jpg`
- PNG: `Practical_05_Name_RollNo.png`
- SVG source: `Practical_05_Artwork.svg`




**Updated PSD note:** The background is included as its own separate raster layer at the bottom of the layer stack, and the artwork elements are on separate layers. Text objects are separate raster layers, not live Type Tool text. For editable wording, recreate text with Photoshop's Type Tool; for native vector shapes, recreate with the Shape Tool.
