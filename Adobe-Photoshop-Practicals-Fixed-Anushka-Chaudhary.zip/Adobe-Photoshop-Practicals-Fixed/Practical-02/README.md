# Practical 02 – Photo Editing & Retouching

## Student Details
- Name: Anushka Chaudhary
- Roll Number: 253026043
- Course: Desktop Publishing – UAC012P

## Files
- `Practical_02_Anushka_Chaudhary_253026043.psd` — white background, separate photo panels and text/label layer.
- `Practical_02_Anushka_Chaudhary_253026043.png` and `Practical_02_Anushka_Chaudhary_253026043.jpg` — final exports.
- `Practical_02_Anushka_Chaudhary_253026043.svg` — source layout with separately identifiable text and image elements.

## Work included
A clean, white-canvas before/after comparison layout. The photo panels are included; there are no insert-your-own-image instructions.
